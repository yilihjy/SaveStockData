package demo;

import java.util.List;

import com.yilihjy.savesinastockdata.*;
/**
 * 
 * @author yilihjy Email:yilihjy@gmail.com
 * @version 1.0.0
 * @date create time：2017年1月7日 下午9:41:27
 *
 */
public class RealTimeDataDemo {

	public static void main(String[] args) {
		String[] codes1 = {"s_sh000001","s_sz399001"};
		List<RealTimeDataPOJO> indexs = RealTimeData.getRealTimeDataObjects(codes1);
		for(RealTimeDataPOJO obj:indexs){
			System.out.println("指数名称："+obj.getName());
			System.out.println("当前点数："+obj.getNow());
			System.out.println("总手"+obj.getVolume());
			System.out.println("成交金额"+obj.getVolumePrice());
			System.out.println("涨跌额"+obj.getRiseAndFall());
			System.out.println("涨跌幅"+obj.getRiseAndFallPercent());
		}
		
		String[] codes2 = {"sz000001","sz000002"};
		List<RealTimeDataPOJO> stocks = RealTimeData.getRealTimeDataObjects(codes2);
		for(RealTimeDataPOJO obj:stocks){
			System.out.println("股票名称："+obj.getName());
			System.out.println("当前股价："+obj.getNow());
			System.out.println("总交易量(股)"+obj.getVolume());
			System.out.println("成交金额"+obj.getVolumePrice());
			System.out.println("竞卖价"+obj.getSellPrice());
			System.out.println("竞买价"+obj.getBuyPrice());
		}
		
	}

}
