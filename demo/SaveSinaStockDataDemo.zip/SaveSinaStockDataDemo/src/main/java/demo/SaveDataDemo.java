package demo;
import java.util.ArrayList;
import java.util.List;

import com.yilihjy.savesinastockdata.*;
/**
 * 
 * @author yilihjy Email:yilihjy@gmail.com
 * @version 1.0.0
 *
 *
 */
public class SaveDataDemo {
	public static void main(String[] args) throws Exception{
		Tools.readExcel2JSON("沪深A股代码及名称（20170105更新）.xlsx", "code.json");
		List<String> codes = new ArrayList<>();
		codes.add("sz000001");
		codes.add("sz000002");
		SaveData sd = new SaveData("testdb","user_name","password");
		if(sd.initDB()){
			sd.insertCode(Tools.getValueFromJSONFile("code.json", "fullCode"), Tools.getValueFromJSONFile("code.json", "code"), Tools.getValueFromJSONFile("code.json", "name"));
			sd.saveHistoryData(codes);
			sd.saveRealTimeData(codes);
		}
	}
}
