package demo;

import java.util.List;

import com.yilihjy.savesinastockdata.*;
/**
 * 
 * @author yilihjy Email:yilihjy@gmail.com
 * @version 1.0.0
 *
 */
public class HistoryDataDemo {

	public static void main(String[] args) {
		String result = HistoryData.get15MKlineData("sz000001");
		System.out.println("json结果："+result);
		List<HistoryDataPOJO> lr = HistoryData.get15MKlineDataObjects("sz000001","30");
		int i = 0;
		for(HistoryDataPOJO obj:lr){
			System.out.print("第"+(++i)+"条 ");
			System.out.print("day:"+obj.getDay()+" ");
			System.out.print("open:"+obj.getOpen()+" ");
			System.out.print("high:"+obj.getHigh()+" ");
			System.out.print("low:"+obj.getLow()+" ");
			System.out.print("close:"+obj.getClose()+" ");
			System.out.print("MA5"+obj.getMA5()+" ");
			System.out.print("MA5volume"+obj.getMA10Volume()+" ");
			System.out.print("MA10"+obj.getMA5()+" ");
			System.out.print("MA10volume"+obj.getMA10Volume()+" ");
			System.out.print("MA30"+obj.getMA30()+" ");
			System.out.println("MA30volume"+obj.getMA30Volume()+" ");
		}
	}

}
